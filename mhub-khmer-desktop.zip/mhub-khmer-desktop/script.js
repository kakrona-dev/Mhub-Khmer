var P='images/';
var D=[
{c:'Combos',n:'Fish Amok Set',d:'Steamed Amok + Jasmine Rice + Iced Tea',p:8.99,t:'BESTSELLER',i:'fish-amok-steamed-in-banana-leaf.jpg'},
{c:'Combos',n:'Lok Lak Combo',d:'Beef Lok Lak + Fried Egg + Rice + Drink',p:9.99,t:'POPULAR',i:'beef-lok-lak-with-rice-and-fried-egg.jpg'},
{c:'Combos',n:'Kuy Teav Bowl',d:'Pork Noodle Soup + Spring Roll + Coffee',p:6.5,t:'SAVE 15%',i:'kuy-teav-noodle-soup-bowl.jpg'},
{c:'Combos',n:'Papaya Salad Set',d:'Papaya Salad + Chicken Wings + Meatballs',p:8.99,t:'NEW',i:'papaya-salad-chicken-wings-and-meatballs.jpg'},
{c:'Soups',n:'Somlor Koko',d:'Herb and vegetable soup with fish',p:5.5,t:'BESTSELLER',i:'somlor-koko-khmer-herb-soup.jpg'},
{c:'Soups',n:'Machu Trey',d:'Sour fish soup',p:5.99,t:'POPULAR',i:'machu-trey.jpg'},
{c:'Soups',n:'Chicken Curry (Somlor Kari)',d:'Khmer chicken curry soup with potato',p:6.25,t:'NEW',i:'chicken-curry-somlor-kari.jpg'},
{c:'Soups',n:'Machu Sach Ko',d:'Clear beef soup with lemongrass',p:6.5,i:'machu-sach-ko.jpg'},
{c:'Rice',n:'Bay Cha Kapik',d:'Shrimp paste fried rice, green mango, sweet pork',p:6.5,t:'BESTSELLER',i:'bay-cha-kapik-shrimp-paste-fried-rice.jpg'},
{c:'Rice',n:'Bay Sach Moan',d:'Chicken rice with soup',p:7.75,t:'POPULAR',i:'bay-sach-moan-chicken-rice.jpg'},
{c:'Rice',n:'Bay Sach Chrouk',d:'Grilled pork with rice and pickles',p:4.5,i:'bay-sach-chrouk.jpg'},
{c:'Rice',n:'Bay Cha',d:'Khmer fried rice with egg',p:4.25,t:'NEW',i:'bay-cha.jpg'},
{c:'Noodles',n:'Kuy Teav',d:'Pork noodle soup with fresh herbs',p:4.5,t:'BESTSELLER',i:'kuy-teav-noodle-soup-bowl.jpg'},
{c:'Noodles',n:'Nom Banh Chok',d:'Rice noodles with fish curry and herbs',p:3.99,t:'POPULAR',i:'nom-banh-chok.jpg'},
{c:'Noodles',n:'Mi Char',d:'Stir-fried noodles with beef and egg',p:4.75,i:'mi-char.jpg'},
{c:'Noodles',n:'Lort Cha',d:'Short rice noodles stir-fried with egg',p:4.25,i:'lort-cha.jpg'},
{c:'Drinks',n:'Iced Coffee',d:'Khmer iced coffee',p:2.25,t:'POPULAR',i:'iced-coffee.jpg'},
{c:'Drinks',n:'Sugarcane Juice',d:'Fresh pressed, served over ice',p:1.75,i:'sugarcane-juice.jpg'},
{c:'Drinks',n:'Coconut Water',d:'Chilled young coconut',p:2,t:'NEW',i:'coconut-water.jpg'},
{c:'Drinks',n:'Iced Lemon Tea',d:'Fresh lemon with Khmer tea',p:1.5,i:'iced-lemon-tea.jpg'}
];
var SL=[
{s:'LIMITED TIME',h:'AUTHENTIC. AROMATIC. KHMER.',p:'100% Real Khmer Flavor. Cooked Fresh. Always.',i:'khmer-fish-soup-bowl-with-fresh-herbs.jpg'},
{s:"CHEF'S PICK",h:'SOMLOR KOKO',p:'Traditional Khmer herb soup with fresh vegetables.',i:'somlor-koko-khmer-herb-soup.jpg'},
{s:'NEW TODAY',h:'BAY CHA KAPIK',p:'Shrimp paste fried rice with green mango and sweet pork.',i:'bay-cha-kapik-shrimp-paste-fried-rice.jpg'}
];
var OF=[
{b:'30%',s:'OFF',n:'30% off Khmer combos',d:'On selected combos.',c:'MHUB30',e:'Valid until Dec 31, 2026'},
{b:'FREE',s:'COFFEE',n:'Free Iced Coffee',d:'With any rice dish you order.',c:'FREECOFFEE',e:'Valid until Nov 30, 2026'},
{b:'$2',s:'OFF',n:'$2 off your order',d:'On any order over $10.',c:'WELCOME2',e:'Valid until Dec 15, 2026'},
{b:'1+1',s:'DRINKS',n:'Buy 1 get 1 drinks',d:'Every Friday on all drinks.',c:'BOGO',e:'Valid until Dec 31, 2026'}
];
var CATS=['All','Combos','Soups','Rice','Noodles','Drinks'];
var S={v:'home',c:'All',q:''},fav={},cart=[],placed=null,hi=0,timer;
var HEART='<svg viewBox="0 0 24 24"><path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.5 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z"/></svg>';
var view=document.getElementById('view'),ord=document.getElementById('ord'),qEl=document.getElementById('q'),toastEl=document.getElementById('toast'),tt;
function toast(m){toastEl.textContent=m;toastEl.classList.add('show');clearTimeout(tt);tt=setTimeout(function(){toastEl.classList.remove('show')},1800)}
function money(x){return '$'+x.toFixed(2)}
function card(it,k){
  return '<article class="card"><div class="ph"><img src="'+P+it.i+'" alt="'+it.n+'" loading="lazy">'+(it.t?'<span class="tag">'+it.t+'</span>':'')+
  '<button class="hrt'+(fav[it.n]?' on':'')+'" data-k="'+k+'" aria-label="Favorite '+it.n+'">'+HEART+'</button></div><h3>'+it.n+'</h3><p>'+it.d+'</p>'+
  '<div class="bt"><strong>'+money(it.p)+'</strong><button class="add" data-k="'+k+'" aria-label="Add '+it.n+'">+</button></div></article>';
}
function chips(){return '<div class="chips">'+CATS.map(function(c){return '<button class="chip'+(S.c===c?' on':'')+'" data-c="'+c+'">'+c+'</button>'}).join('')+'</div>'}
function items(){
  var q=S.q.toLowerCase();
  return D.map(function(x,k){return{x:x,k:k}}).filter(function(o){
    if(S.v==='fav'&&!fav[o.x.n])return false;
    if(S.v==='home'&&S.c==='All'&&o.x.c!=='Combos')return false;
    if(S.v!=='fav'&&S.c!=='All'&&o.x.c!==S.c)return false;
    return !q||(o.x.n+' '+o.x.d).toLowerCase().indexOf(q)>-1;
  });
}
function grid(title){
  var l=items();
  return '<div class="sec"><h2>'+title+'</h2><span>'+l.length+' dish'+(l.length===1?'':'es')+'</span></div><div class="grid">'+
  (l.length?l.map(function(o){return card(o.x,o.k)}).join(''):'<p class="empty">'+(S.v==='fav'?'No favorites yet. Click the heart on a dish to save it.':'No dishes found.')+'</p>')+'</div>';
}
function hero(){
  return '<div class="hero">'+SL.map(function(s,i){return '<div class="sl'+(i===hi?' on':'')+'"><div class="tx"><small>'+s.s+'</small><h2>'+s.h+'</h2><p>'+s.p+'</p><button class="go" data-go="menu">Order Now &rarr;</button></div><div class="im"><img src="'+P+s.i+'" alt="'+s.h+'"></div></div>'}).join('')+
  '<div class="dots">'+SL.map(function(s,i){return '<button data-d="'+i+'" class="'+(i===hi?'on':'')+'" aria-label="Slide '+(i+1)+'"></button>'}).join('')+'</div></div>';
}
function render(){
  var h='';
  if(S.v==='home')h=hero()+chips()+grid(S.c==='All'?'Popular Combos':S.c==='Combos'?'Popular Combos':S.c);
  if(S.v==='menu')h=chips()+grid('Full Menu');
  if(S.v==='fav')h=grid('Favorites');
  if(S.v==='offers')h='<div class="sec"><h2>My Offers</h2><span>'+OF.length+' offers available</span></div><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(340px,1fr))">'+OF.map(function(o){return '<div class="vc"><div class="st"><b>'+o.b+'</b><small>'+o.s+'</small></div><div class="bx"><h3>'+o.n+'</h3><p>'+o.d+'</p><span class="code">'+o.c+'</span><small class="e">'+o.e+'</small></div></div>'}).join('')+'</div>';
  view.innerHTML=h;
  document.querySelectorAll('#nav .nv').forEach(function(b){b.classList.toggle('on',b.dataset.v===S.v)});
  clearInterval(timer);
  if(S.v==='home'&&!matchMedia('(prefers-reduced-motion:reduce)').matches)timer=setInterval(function(){slide(hi+1)},4500);
}
function slide(i){
  hi=(i+SL.length)%SL.length;
  document.querySelectorAll('.sl').forEach(function(e,k){e.classList.toggle('on',k===hi)});
  document.querySelectorAll('.dots button').forEach(function(e,k){e.classList.toggle('on',k===hi)});
}
function qty(){return cart.reduce(function(s,i){return s+i.q},0)}
function total(){return cart.reduce(function(s,i){return s+i.q*i.x.p},0)}
function renderOrd(){
  var n=qty(),h='<h2>My Order</h2><p class="sub">'+(n?'You have '+n+' item'+(n===1?'':'s')+' ('+cart.length+' dish'+(cart.length===1?'':'es')+')':'Nothing added yet')+'</p>';
  if(placed!==null)h+='<div class="oe"><b>Order placed!</b>You ordered '+placed.n+' item'+(placed.n===1?'':'s')+'.<br>Total: '+money(placed.t)+'</div>';
  else if(!n)h+='<div class="oe"><b>No orders yet</b>Click the + button on any dish to add it here.</div>';
  else h+=cart.map(function(c,k){return '<div class="oi"><img src="'+P+c.x.i+'" alt=""><div class="in"><h4>'+c.x.n+'</h4><div class="pr">'+money(c.x.p*c.q)+'</div></div><div class="qt"><button data-m="'+k+'" aria-label="Remove one">&minus;</button><span>'+c.q+'</span><button class="pl" data-p="'+k+'" aria-label="Add one">+</button></div></div>'}).join('')+
    '<div class="tot"><span>Total</span><span>'+money(total())+'</span></div><button class="co" id="co">Place Order</button>';
  ord.innerHTML=h;
}
function add(k){
  var f=cart.filter(function(c){return c.x===D[k]})[0];
  if(f)f.q++;else cart.push({x:D[k],q:1});
  placed=null;renderOrd();toast(qty()+' item'+(qty()===1?'':'s')+' in your order');
}
view.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.dataset.c){S.c=t.dataset.c;render()}
  else if(t.dataset.d){slide(+t.dataset.d)}
  else if(t.dataset.go){S.v='menu';S.c='All';render()}
  else if(t.classList.contains('add'))add(+t.dataset.k);
  else if(t.classList.contains('hrt')){var it=D[+t.dataset.k];if(fav[it.n])delete fav[it.n];else fav[it.n]=1;toast(fav[it.n]?'Added to favorites':'Removed from favorites');S.v==='fav'?render():t.classList.toggle('on',!!fav[it.n]);document.querySelectorAll('.hrt').forEach(function(b){b.classList.toggle('on',!!fav[D[+b.dataset.k].n])})}
});
ord.addEventListener('click',function(e){
  var t=e.target.closest('button');if(!t)return;
  if(t.dataset.p!==undefined)cart[+t.dataset.p].q++;
  else if(t.dataset.m!==undefined){var k=+t.dataset.m;if(--cart[k].q<=0)cart.splice(k,1)}
  else if(t.id==='co'){placed={n:qty(),t:total()};cart=[]}
  renderOrd();
});
document.getElementById('nav').addEventListener('click',function(e){var b=e.target.closest('.nv');if(!b)return;S.v=b.dataset.v;S.c='All';render()});
qEl.addEventListener('input',function(){S.q=qEl.value.trim();if(S.v==='home'||S.v==='offers'){S.v='menu'}render()});
document.getElementById('bell').addEventListener('click',function(){toast('3 new: 30% off combos, new dish Bay Cha, free Iced Coffee')});
render();renderOrd();
